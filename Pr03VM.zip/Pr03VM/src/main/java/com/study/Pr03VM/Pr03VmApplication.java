package com.study.Pr03VM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr03VmApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr03VmApplication.class, args);
	}

}
