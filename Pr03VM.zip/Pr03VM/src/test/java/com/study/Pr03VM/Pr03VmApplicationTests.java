package com.study.Pr03VM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr03VmApplicationTests {

	@Test
	void contextLoads() {
	}

}
